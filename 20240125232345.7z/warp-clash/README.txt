点击start.bat生成
如果您需要自定义clash文件模板请修改template.yaml

密钥格式为44 个字符
样例如下：KIV2EsjDNA3mF60Sfedfvy9Xk8man/9MXedJqxwefEo= 